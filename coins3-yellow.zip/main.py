import PuzzleHunt
num = 1
while num < 27: 
	PuzzleHunt.reverse_caesar_shift("DWBYQCIQV",num)
	num += 1
