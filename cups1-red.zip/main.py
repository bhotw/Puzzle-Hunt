import PuzzleHunt
def is_even(num):
	if num % 2 == 0:
		return True
	else:
		return False
		
		

print(is_even(3))

PuzzleHunt.test_is_even(is_even) 
